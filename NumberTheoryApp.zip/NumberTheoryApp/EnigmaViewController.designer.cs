// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace NumberTheoryApp
{
    [Register ("EnigmaViewController")]
    partial class EnigmaViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel error_field { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel message_restate { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField message_txt { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel new_message { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField reflect_order { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel reflect_output { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton reset_bttn { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField rotor_order { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel rotor1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel rotor2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel rotor3 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel rotor4 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel rotor5 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel rotor6 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton submit_button { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField top_letter { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (error_field != null) {
                error_field.Dispose ();
                error_field = null;
            }

            if (message_restate != null) {
                message_restate.Dispose ();
                message_restate = null;
            }

            if (message_txt != null) {
                message_txt.Dispose ();
                message_txt = null;
            }

            if (new_message != null) {
                new_message.Dispose ();
                new_message = null;
            }

            if (reflect_order != null) {
                reflect_order.Dispose ();
                reflect_order = null;
            }

            if (reflect_output != null) {
                reflect_output.Dispose ();
                reflect_output = null;
            }

            if (reset_bttn != null) {
                reset_bttn.Dispose ();
                reset_bttn = null;
            }

            if (rotor_order != null) {
                rotor_order.Dispose ();
                rotor_order = null;
            }

            if (rotor1 != null) {
                rotor1.Dispose ();
                rotor1 = null;
            }

            if (rotor2 != null) {
                rotor2.Dispose ();
                rotor2 = null;
            }

            if (rotor3 != null) {
                rotor3.Dispose ();
                rotor3 = null;
            }

            if (rotor4 != null) {
                rotor4.Dispose ();
                rotor4 = null;
            }

            if (rotor5 != null) {
                rotor5.Dispose ();
                rotor5 = null;
            }

            if (rotor6 != null) {
                rotor6.Dispose ();
                rotor6 = null;
            }

            if (submit_button != null) {
                submit_button.Dispose ();
                submit_button = null;
            }

            if (top_letter != null) {
                top_letter.Dispose ();
                top_letter = null;
            }
        }
    }
}