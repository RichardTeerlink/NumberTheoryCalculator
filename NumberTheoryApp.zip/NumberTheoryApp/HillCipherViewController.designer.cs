// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace NumberTheoryApp
{
    [Register ("HillCipherViewController")]
    partial class HillCipherViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel askDecrypt { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel askInverse { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel encryptHill { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton encryptHillMessage { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField encryptHillTry { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField hillInverse { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField hillMatrix { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView hillMatrixView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField hillMessageUser { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton matrixButton { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel showDecrypt { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel showInverse { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel showMatrix { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel showMessage { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton startDecrypt { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton submitInverse { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton testHill { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField userDecrypt { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel viewHillTry { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (askDecrypt != null) {
                askDecrypt.Dispose ();
                askDecrypt = null;
            }

            if (askInverse != null) {
                askInverse.Dispose ();
                askInverse = null;
            }

            if (encryptHill != null) {
                encryptHill.Dispose ();
                encryptHill = null;
            }

            if (encryptHillMessage != null) {
                encryptHillMessage.Dispose ();
                encryptHillMessage = null;
            }

            if (encryptHillTry != null) {
                encryptHillTry.Dispose ();
                encryptHillTry = null;
            }

            if (hillInverse != null) {
                hillInverse.Dispose ();
                hillInverse = null;
            }

            if (hillMatrix != null) {
                hillMatrix.Dispose ();
                hillMatrix = null;
            }

            if (hillMatrixView != null) {
                hillMatrixView.Dispose ();
                hillMatrixView = null;
            }

            if (hillMessageUser != null) {
                hillMessageUser.Dispose ();
                hillMessageUser = null;
            }

            if (matrixButton != null) {
                matrixButton.Dispose ();
                matrixButton = null;
            }

            if (showDecrypt != null) {
                showDecrypt.Dispose ();
                showDecrypt = null;
            }

            if (showInverse != null) {
                showInverse.Dispose ();
                showInverse = null;
            }

            if (showMatrix != null) {
                showMatrix.Dispose ();
                showMatrix = null;
            }

            if (showMessage != null) {
                showMessage.Dispose ();
                showMessage = null;
            }

            if (startDecrypt != null) {
                startDecrypt.Dispose ();
                startDecrypt = null;
            }

            if (submitInverse != null) {
                submitInverse.Dispose ();
                submitInverse = null;
            }

            if (testHill != null) {
                testHill.Dispose ();
                testHill = null;
            }

            if (userDecrypt != null) {
                userDecrypt.Dispose ();
                userDecrypt = null;
            }

            if (viewHillTry != null) {
                viewHillTry.Dispose ();
                viewHillTry = null;
            }
        }
    }
}