// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace NumberTheoryApp
{
    [Register ("RSAViewController")]
    partial class RSAViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField base_10 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField base_27 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField block_size { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton decryptButton { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField enc_block { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton encButton { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel error_field_1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel error_field_2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel error_field_3 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel error_field_4 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel error_field_5 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField MessageText { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField out_block_size { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField pri_key { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField pub_key { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton submit1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton submit2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton submit3 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton submit4 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton submit5 { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (base_10 != null) {
                base_10.Dispose ();
                base_10 = null;
            }

            if (base_27 != null) {
                base_27.Dispose ();
                base_27 = null;
            }

            if (block_size != null) {
                block_size.Dispose ();
                block_size = null;
            }

            if (decryptButton != null) {
                decryptButton.Dispose ();
                decryptButton = null;
            }

            if (enc_block != null) {
                enc_block.Dispose ();
                enc_block = null;
            }

            if (encButton != null) {
                encButton.Dispose ();
                encButton = null;
            }

            if (error_field_1 != null) {
                error_field_1.Dispose ();
                error_field_1 = null;
            }

            if (error_field_2 != null) {
                error_field_2.Dispose ();
                error_field_2 = null;
            }

            if (error_field_3 != null) {
                error_field_3.Dispose ();
                error_field_3 = null;
            }

            if (error_field_4 != null) {
                error_field_4.Dispose ();
                error_field_4 = null;
            }

            if (error_field_5 != null) {
                error_field_5.Dispose ();
                error_field_5 = null;
            }

            if (MessageText != null) {
                MessageText.Dispose ();
                MessageText = null;
            }

            if (out_block_size != null) {
                out_block_size.Dispose ();
                out_block_size = null;
            }

            if (pri_key != null) {
                pri_key.Dispose ();
                pri_key = null;
            }

            if (pub_key != null) {
                pub_key.Dispose ();
                pub_key = null;
            }

            if (submit1 != null) {
                submit1.Dispose ();
                submit1 = null;
            }

            if (submit2 != null) {
                submit2.Dispose ();
                submit2 = null;
            }

            if (submit3 != null) {
                submit3.Dispose ();
                submit3 = null;
            }

            if (submit4 != null) {
                submit4.Dispose ();
                submit4 = null;
            }

            if (submit5 != null) {
                submit5.Dispose ();
                submit5 = null;
            }
        }
    }
}